export interface PontoColeta {
  id: string;
  nome: string;
  materiais: string[];
  latitude: number;
  longitude: number;
}
